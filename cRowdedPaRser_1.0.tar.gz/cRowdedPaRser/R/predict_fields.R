#' predict_fields function
#'
#' This function predicts field names using an xgboost prebuilt model. 
#' @param data a data frame of new data.
#' @keywords prediction, the oracle
#' @export
#' @examples
#' predict_fields()

predict_fields <- function(data){
	data(class_codes)
	print(class_codes)
	data$row_names <- NULL
	data$file_name <- NULL
	strings1 <- data$strings
	data$strings <- NULL
	data <- as.matrix(data)
	d_new <- xgb.DMatrix(data)
	model1 <- xgb.load('./cRowdedPaRser/data/model1.model')
	pr1 <- predict(model1, d_new)
	pr1 <- matrix(pr1, ncol=10, byrow=TRUE) # reshape it to a num_class-columns matrix
	predicted_labels <- max.col(pr1) - 1 # convert the probabilities to softmax labels
	for(i in 1:length(class_codes[,1])){	
		w <- which(predicted_labels == class_codes$code[i])
		predicted_labels[w] <- class_codes$name[i]
	}
	print(as.data.frame(cbind(strings1,predicted_labels),stringsAsFactors = FALSE))
}

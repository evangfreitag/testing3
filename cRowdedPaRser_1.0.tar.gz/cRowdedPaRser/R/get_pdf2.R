#' get_pdf2 function
#'
#' This function retrieves pdf files using the "pdftools" package. 
#' It also uses data.table and tokenizers packages.
#' @param file_location A character vector of file locations.
#' @keywords file i/o
#' @export
#' @examples pdf_list <- get_pdf2("C:/Users/Evan/Documents/Crowded2/src")
#' get_pdf2()

get_pdf2 <- function(file_location){

	files_in_dir <- list.files(file_location)
	w <- which(endsWith(files_in_dir,"pdf") == TRUE)
	pdf_files_in_dir <- files_in_dir[w]

	pdf_out_list <- list()
	for(i in 1:length(pdf_files_in_dir)){
		pdf_file <- file.path(file_location, pdf_files_in_dir[i])
		text <- try(pdf_text(pdf_file))
		text <- iconv(text, "latin1", "ASCII", "byte")
		text <- unlist(strsplit(text, "\r\n", fixed = TRUE))
		if(identical(text,character(0)) == FALSE){
			text <- unlist(strsplit(text, "\n", fixed = TRUE))
			text <- gsub("\t", "    ", text, fixed = TRUE)
			text <- as.data.frame(text, stringsAsFactors = FALSE)
			colnames(text) <- "strings"
			text <- fix_encoding(text)
			pdf_out_list[[i]] <- text
		}
	}
	names(pdf_out_list) <- pdf_files_in_dir

	w <- which(unlist(lapply(pdf_out_list,length)) == 0)
	bad_pdf_out_list <- pdf_out_list[w]
	print(paste("failures: ",names(pdf_out_list)[w],sep=""))

	pdf_out_list <- pdf_out_list[-w]
	pdf_out_list <- lapply(pdf_out_list, function(x){
		x <- as.data.frame(x, stringsAsFactors = FALSE)
		colnames(x) <- "strings"
		x
	})
	return(pdf_out_list)
}
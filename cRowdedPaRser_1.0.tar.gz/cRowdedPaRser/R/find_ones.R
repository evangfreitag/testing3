#' find_ones function
#'
#' This checks for "loose" matches (i.e. the word occurs anywhere in the string).
#' @param x, y, indicator character vectors (or lists).
#' @keywords feature extraction
#' @export
#' @examples
#' find_ones()

find_ones <- function(x,y,indicator){
	x$new_var <- 0
	w2 <- which(is.na(y) == FALSE)
	if(length(w2) > 0){x$new_var[w2] <- 1}
	colnames(x)[which(colnames(x) == "new_var")] <- indicator
	x
}
#' fix_encoding function
#'
#' This function fixes common character representations.
#' @param y A character vector.
#' @keywords enacoding
#' @export
#' @examples
#' fix_encoding()

fix_encoding <- function(y){
	x <- y$strings
	x <- gsub("<c2><a0>"," ",x)
	x <- gsub("<e2><80><90>", "-", x) # HYPHEN
	x <- gsub("<e2><80><91>", "-", x) # NON-BREAKING HYPHEN
	x <- gsub("<e2><80><92>", "-", x) # FIGURE DASH
	x <- gsub("<e2><80><93>", "-", x) # EN DASH
	x <- gsub("<e2><80><94>", "-", x) # EM DASH
	x <- gsub("<e2><80><95>", "-", x) # HORIZONTAL BAR
	x <- gsub("<ef><82><b7>", "*", x) # white box
	x <- gsub("<ef><83><bc>", "*", x) # white box
	x <- gsub("<e2><80><99>", "'", x) # quote
	x <- gsub("<e2><80><98>", "'", x) # quote
	x <- gsub("<e2><80><9c>", "'", x) # quote
	x <- gsub("<e2><80><9d>", "'", x) # quote
	x <- gsub("<e2><80><a2>", "*", x) # BULLET
	x <- gsub("<e2><97><8f>", "*", x) # BLACK circlE
	x <- gsub("<e2><80><8b>", "", x) # ZERO WIDTH SPACE
	x <- gsub("<e2><80><a8>", "", x) # LINE SEPARATOR
	x <- gsub("<e2><80><a6>", "...", x) #HORIZONTAL ELLIPSIS
	x <- gsub("<ef><82><9e>", ",", x) # white box
	x <- gsub("<ef><82><a7>", "*", x) # white box
	x <- gsub("<e2><97><8b>", "*", x) # white CIRCLE
	x <- gsub("<e2><96><a0>", "*", x) # BLACK SQUARE
	x <- gsub("<ef><ac><81>", "fi", x) # FI
	x <- gsub("<ef><ac><82>", "fl", x) # FL
	x <- gsub("<ef><ac><80>", "ff", x) # FF
	x <- gsub("<ef><ac><83>", "ff", x) # FF
	x <- gsub("<e2><99><a6>", "*", x) # wHITE BOX
	x <- gsub("<ef><81><b6>", "*", x) # wHITE BOX
	x <- gsub("<e2><80><a9>", "", x) # PARAGRAPH SEPARATOR
	x <- gsub("<e2><96><aa>", "*", x) # blkack BOX
	x <- gsub("<e2><88><97>", "*", x) # ASTERISK OPERATOR
	x <- gsub("<e2><9c><a6>", "*", x) # BLACK FOUR POINTED STAR
	x <- gsub("<e2><96><b6>", "*", x) # BLACK RIGHT-POINTING TRIANGLE
	x <- gsub("<e2><ac><a5>", "*", x) # BLACK MEDIUM DIAMOND
	x <- gsub("<b8><c6><8b>", "Y", x) # LATIN CAPITAL LETTER Y WITH DIAERESIS
	x <- gsub("<c6><8b>", "D", x) # LATIN CAPITAL LETTER D WITH TOPBAR
	x <- gsub("<f0><9f><93><b1>", "PHONE", x) # MOBILE PHONE
	x <- gsub("<f0><9f><93><a7>", "EMAIL", x) # E-MAIL SYMBOL
	x <- gsub("<c2><b7>", "*", x) # MIDDLE DOT
	x <- gsub("<c3><a7>", "c", x) # c with the under hook
	x <- gsub("<c2><ad>", "-", x) # 	SOFT HYPHEN
	x <- gsub("<c3><88>", "E", x) # LATIN CAPITAL LETTER E WITH GRAVE
	x <- gsub("<c3><ad>", "i", x) # LATIN LETTER i WITH GRAVE
	x <- gsub("<c3><a9>", "e", x) # LATIN LETTER e WITH GRAVE
	x <- gsub("<c3><b1>", "n", x)	# LATIN SMALL LETTER N WITH TILDE
	x <- gsub("<c3><ba>", "u", x)	# LATIN SMALL LETTER U WITH ACUTE
	x <- gsub("<c3><89>", "E", x)	# LATIN CAPITAL LETTER E WITH ACUTE
	y$strings <- gsub("<c3><b3>", "o", x)	# LATIN SMALL LETTER O WITH ACUTE
	y
}
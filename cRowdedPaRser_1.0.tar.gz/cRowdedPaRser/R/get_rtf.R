#' get_rtf function
#'
#' This function retrieves rtf files using the "unrtf" package. 
#' devtools::install_github("ropensci/unrtf")
#' It also uses data.table and tokenizers packages.
#' @param file_location A character vector of file locations.
#' @keywords file i/o
#' @export
#' @examples rtf_list <- get_rtf("C:/Users/Evan/Documents/Crowded2/src")
#' get_rtf()

get_rtf <- function(file_location){
	files_in_dir <- list.files(file_location)
	w <- which(endsWith(files_in_dir,"rtf") == TRUE)
	pdf_files_in_dir <- files_in_dir[w]

	raw_text <- list()
	pdf_out_list <- list()

	for(i in 1:length(pdf_files_in_dir)){
		url_name <- paste(file_location, pdf_files_in_dir[i],sep ="/")
		raw_text[[i]] <- try(unrtf(url_name, format = "text"))		
		bytes_text <- iconv(raw_text[[i]], "latin1", "ASCII", "byte")
		line_tok_bytes_text <- unlist(tokenize_lines(bytes_text))
	
		if(length(line_tok_bytes_text) > 0){
			line_tok_bytes_text <- as.data.frame(line_tok_bytes_text, stringsAsFactors = FALSE)
			colnames(line_tok_bytes_text) <- "strings"
			line_tok_bytes_text$strings <- gsub("\t", "    ", line_tok_bytes_text$strings, fixed = TRUE)
			line_tok_bytes_text$file_name <- pdf_files_in_dir[i]
			line_tok_bytes_text <- fix_encoding(line_tok_bytes_text)
			pdf_out_list[[i]] <- line_tok_bytes_text	
		}	
	}	
	w <- which(lapply(pdf_out_list,function(x){print(length(x$strings))}) == 0)
	if(length(w) > 0){
		pdf_out_list <- pdf_out_list[-w]
		print(paste("failures: ", pdf_files_in_dir[w], sep=""))
		pdf_files_in_dir <- pdf_files_in_dir[-w]		
	}
	names(pdf_out_list) <- pdf_files_in_dir
	return(pdf_out_list)
}

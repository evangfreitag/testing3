#' regex_extraction function
#'
#' This checks for several pattern types and generates a 0-1 feature. Uses the qdapRegex package
#' @param x A data frame with a column named strings.
#' @keywords feature extraction
#' @export
#' @examples
#' regex_extraction()

regex_extraction <- function(x){
	x <- find_symbols(x,"*","contains_bullet")
	x <- find_symbols(x,":","contains_colon")
	x <- find_symbols(x,";","contains_semicolon")
	x <- find_symbols(x,"-","contains_hyphen")
	x <- find_symbols(x,"/","contains_backslash")
	x <- find_symbols(x,"@","contains_at")
	x <- find_symbols(x,"+","contains_plus")
	x
}
#' feature_generator function
#'
#' This wraps the various feature generators
#' @param x A list of dataframes.
#' @keywords feature extraction
#' @export
#' @examples
#' feature_generator()

feature_generator <- function(x){
	x <- lapply(x, qdap_regex_extraction)
	x <- lapply(x, regex_extraction)
	x <- lapply(x, regex_count_extraction)
	x <- lapply(x, generate_location_features)
	x <- lapply(x, generate_match_features)
	x
}

#' get_pdf_table function
#'
#' This function retrieves tables in a pdf using the "tabulizer" package. 
#' @param file_location A character vector of file locations.
#' @keywords tables
#' @export
#' @examples pdf_list <- get_pdf_table("C:/Users/Evan/Documents/Crowded2/src")
#' get_pdf_table()

get_pdf_table <- function(file_location){

	files_in_dir <- list.files(file_location)
	w <- which(endsWith(files_in_dir,"pdf") == TRUE)
	pdf_files_in_dir <- files_in_dir[w]

	raw_table <- list()
	pdf_table_out_list <- list()

	for(i in 1:length(pdf_files_in_dir)){
		url_name <- paste(file_location, pdf_files_in_dir[i],sep ="/")
		raw_table[[i]] <- try(extract_tables(url_name))		
		pdf_table_out_list[[i]] <- raw_table	
	}	
	names(pdf_table_out_list) <- pdf_files_in_dir
	return(pdf_table_out_list)
}

